import logging

logger = logging.getLogger("grading")

logging.basicConfig(level=logging.DEBUG)